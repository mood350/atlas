package com.atlas.backend.token;

public enum TokenType {
    ACTIVATION,
    PASSWORD_RESET
}
